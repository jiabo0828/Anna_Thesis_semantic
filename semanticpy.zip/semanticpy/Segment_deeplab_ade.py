
import csv
import os
from itertools import islice
import mxnet as mx
from mxnet import image, gpu
import gluoncv
from gluoncv.data.transforms.presets.segmentation import test_transform
from gluoncv.utils.viz import get_color_pallete,plot_image
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import matplotlib
matplotlib.use('Agg')
import pandas as pd
import cv2

file_path = './out'
out_path='./pic'
filelist_out = os.listdir(out_path)

max_size=1800
# reshape_size
reshape_size=1000

import warnings; warnings.filterwarnings(action='once')
warnings.filterwarnings("ignore")

ctx = mx.cpu(0)

def ReadLable():
    col_map_dict={}
    filepath='./lable.csv'
    with open(filepath, encoding='GBK') as f:
        reader = csv.reader(f, skipinitialspace=True)
        # osm_id highway bridge angle Lng Lat ID
        for row in islice(reader, 1, None):
            id=int(row[0])-1
            Name=row[4]
            col_map_dict[id]=Name
    return col_map_dict

col_map =ReadLable()
# save as pd.Series
def get_seg(file, model):
    img = image.imread(file)
    img = test_transform(img,ctx=ctx)
    output = model.predict(img)
    predict = mx.nd.squeeze(mx.nd.argmax(output, 1)).asnumpy()
    pred = []
    for i in range(150):
        pred.append((len(predict[predict==i])/(predict.shape[0]*predict.shape[1])))
    pred = pd.Series(pred).rename(col_map)
    return pred

model = gluoncv.model_zoo.get_model('deeplab_resnest101_ade',ctx=ctx,pretrained=True )

filelist = os.listdir(file_path)
col=['id','lng','lat','pixels']
for k in col_map.keys():
    col.append(col_map[k])
df = pd.DataFrame(columns=col)
print(df)

for i in filelist: # save as pd.DataFrame
    # i
    if i not in filelist_out:
        img_path = os.path.join(file_path, i)
        img_id = i
        # lnglat
        lng = 0
        lat = 0

        img = cv2.imread(img_path)
        img_path = img_path.replace('pic', 'image_processed')
        ori_size=[img.shape[1],img.shape[0]]
        # maxsize
        if ori_size[0]>max_size:
            Scale_Factor=ori_size[0]/reshape_size
            img_size = (int(ori_size[0]/Scale_Factor), int(ori_size[1]/Scale_Factor))
            print(i,ori_size,'Resize to:',img_size)
        else:
            img_size = (int(ori_size[0]), int(ori_size[1]))

        img2 = cv2.resize(img, img_size, interpolation=cv2.INTER_CUBIC)
        cv2.imwrite(img_path, img2)

        pixels = img_size[0]*img_size[1]
        data_i = pd.Series({'id': img_id, 'lng': lng, 'lat': lat, 'pixels': pixels}).append(get_seg(img_path, model))
        new_col=pd.DataFrame(data_i).T
        df = pd.concat([df, new_col], axis=0, join='outer', ignore_index=True)

        img = image.imread(img_path)
        img = test_transform(img,ctx=ctx)
        output = model.predict(img)
        predict = mx.nd.squeeze(mx.nd.argmax(output, 1)).asnumpy()

        # viz
        mask = get_color_pallete(predict, 'ade20k')
        print(i+' seg has saved!')
        base = mpimg.imread(img_path)
        plt.figure(figsize=(10,5))
        plt.imshow(base)
        # color
        plt.imshow(mask,alpha=0.8)
        plt.axis('off')
        plt.savefig(out_path+'/'+i,dpi=300,bbox_inches='tight')
        plt.close('all')
        # save as csv
        df.to_csv("./img_seg_deeplab_ade20k.csv")
    else:
        print(i,'already！')
